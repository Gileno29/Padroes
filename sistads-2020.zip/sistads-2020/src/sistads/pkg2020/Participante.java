/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistads.pkg2020;

/**
 *
 * @author silva
 */
public abstract class Participante {
    
    private String nome;
    
    
     public String getNome() {
        throw new UnsupportedOperationException();
    }
 
   
    public void adicionar(Participante participante) {
        throw new UnsupportedOperationException();
    }
 
    public void remover(Participante participante) {
        throw new UnsupportedOperationException();
    }
 
    
}
